Nume: Năstase Robert - Ionut
Grupa: 322 CA

Fișierele din arhiva:
- in = folder care conține testele de input;
- out = folder care conține rezultatele obținute în urma rulării soluțiilor propuse;
- kruskal.cpp = fișier care conține prima soluție propusă (Algoritmul lui Kruskal);
- prim.cpp = fișier care conține a doua soluție propusă (Algoritmul lui Prim);
- Makefile = fișier care conține reguli de rulare ale algoritmilor:
	- make build : regulă pentru compilare;
	- make run-p1 : pentru testarea algoritmului 1;
	- make run-p2 : pentru testarea celui de-al doilea algoritm;
	- make run-best: pentru testarea celui mai bun algoritm evaluat;
	- make clean : regulă de ștergere a fișierelor rezultate.

ID-ul testului propus pentru competiție: 16

Conținut preluat din surse externe (cod pentru al doilea algoritm): https://infoarena.ro/job_detail/2948364?action=view-source
(ultima accesare: 09/01/2023)