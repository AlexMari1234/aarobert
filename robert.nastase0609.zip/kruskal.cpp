#include<bits/stdc++.h>
#include<time.h>

using namespace std;

ifstream fin("test.in");
ofstream fout("test.out");

struct elem
{
    long long sursa,destinatie,cost;
} v[200005];

elem ans[500002];
long long dim[200005],tata[500005],n,m,costapm,k;

inline bool cmp(const elem &a,const elem &b)
{
    return a.cost<b.cost;
}

long long tata_multime(long long x)
{
    if(x!=tata[x])
        tata[x]=tata_multime(tata[x]);
    return tata[x];
}

void unire(long long x,long long y)
{
    x=tata_multime(x);
    y=tata_multime(y);
    if(dim[x]<=dim[y])
    {
        dim[y]+=dim[x];
        tata[x]=y;
    }
    else
    {
        dim[x]+=dim[y];
        tata[y]=x;
    }
}

int main()
{
    double exectime;
    clock_t start, end;
    start = clock();

    long long i;
    fin>>n>>m;
    for(i=1; i<=m; i++)
        fin>>v[i].sursa>>v[i].destinatie>>v[i].cost;
    for(i=1; i<=n; i++)
    {
        dim[i]=1;
        tata[i]=i;
    }
    sort(v+1,v+m+1,cmp);
    for(i=1; i<=m&&k<n-1; i++)
    {
        if(tata_multime(v[i].sursa)!=tata_multime(v[i].destinatie))
        {
            unire(v[i].sursa,v[i].destinatie);
        costapm+=v[i].cost;
        ans[++k]=v[i];
        }
    }
    fout<<costapm<<'\n';
    for(i=1; i<=k; i++)
        fout<<ans[i].sursa - 1<<" "<<ans[i].destinatie - 1<<'\n';

    end = clock();
    exectime = ((double)(end - start))/CLOCKS_PER_SEC;

    fout << "Test" << " " << exectime << '\n';

    return 0;
}
