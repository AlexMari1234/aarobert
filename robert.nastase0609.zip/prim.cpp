#include <fstream>
#include <vector>
#include <queue>
#include <time.h>

using namespace std;

ifstream fin("test.in");
ofstream fout("test.out");

long long N, M; // nr. noduri, nr. muchii
vector<pair<long long, long long>> *listaAd;
vector<long long> tata;
vector<long long> d;
vector<long long> viz;
const long long inf = 1e9;
long long costTotal;

void init(){
    listaAd = new vector<pair<long long, long long>> [N+1]; // nod, cost
    tata    = vector<long long>  (N+1);    // tata[u] = acest v�rf din arbore pentru care se realizeaza minimul
    d       = vector<long long>  (N+1); // d[u] = costul minim al unei muchii de la un varf selectat deja in arbore
    viz     = vector<long long> (N+1);
    for(long long u = 1; u <= N; u++)
        viz[u] = 0, d[u] = inf;
}

void read(){
    fin >> N >> M;
    init();
    for(long long i = 0; i < M; i++){
        long long u, v, c;
        fin >> u >> v >> c;
        u++;
        v++;
        listaAd[u].emplace_back(v, c);
        listaAd[v].emplace_back(u, c);
    }
}

void prim(long long s = 1){
    priority_queue<pair<long long, long long>, vector<pair<long long, long long>>, greater<>> q; // tata, d
    d[s] = 0;
    q.push({0, s});
    while(!q.empty()){
        long long u = q.top().second; // varful nevizitat cu d minim
        q.pop();
        viz[u]++;
        if(viz[u] == 1){ // daca este prima extragere din q a lui u relaxam arcele
            for(const auto & p: listaAd[u]){
                auto v = p.first;
                auto c = p.second;
                if(viz[v] == 0){
                    if(c < d[v]){
                        tata[v] = u;
                        d[v] = c;
                        q.push({d[v], v});
                    }
                }
            }
        }
    }
    vector<pair<long long, long long>> apm;
    for(long long i = 2; i <= N; i++){
        costTotal += d[i];
        apm.emplace_back(i, tata[i]);
    }
    fout << costTotal << '\n';
    for(const auto & muchie: apm)
        fout << muchie.first - 1 << ' ' << muchie.second - 1 << '\n';
}

int main() {
    double exectime;
    clock_t start, end;
    start = clock();

    read();
    prim(1);

    end = clock();
    exectime = ((double)(end - start))/CLOCKS_PER_SEC;

    fout << "Test" << " " << exectime << '\n';

    return 0;
}
